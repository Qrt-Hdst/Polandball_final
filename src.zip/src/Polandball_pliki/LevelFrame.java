package Polandball_pliki;


import sun.plugin2.message.ShowStatusMessage;

import javax.swing.*;

import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.event.ActionEvent;
import static Polandball_pliki.GetConstans.*;

/**
 * Okno gry, zawierające plansze konkretnego poziomu, informacje o stanie rozgrywki
 */

public class LevelFrame extends JFrame implements WindowListener, ActionListener {

    /**
     * Zmienna odliczajaca czas odswiezenia
     */
    public static Timer tm;
    /**
     * kontruktor klasy LevelFrame, zawierjący funkcję initLevelFrame
     */

    public LevelFrame() {
        initLevelFrame();
    }

    /**
     * funkcja zawierająca parametry i poszczególne panele gry
     */

    private void initLevelFrame() {
        // zamkniecie okna gry nie powoduje
        this.setSize(Boardwidth, Boardheight);
        this.setLayout(null);
        this.addWindowListener(this);

        //panel, który będzie naszą plansza do dodawania elementów poziomu
        PanelBoard panelboard = new PanelBoard();
        add(panelboard);
        panelboard.setVisible(true);

        //panel gorny, w ktorym beda informacje dotyczace gry
        PanelInfoOne panelinfoone = new PanelInfoOne();
        add(panelinfoone);
        panelinfoone.setVisible(true);

        //panel boczny, w ktorym beda pozostale informacje
        PanelInfoTwo panelinfotwo = new PanelInfoTwo();
        add(panelinfotwo);
        panelinfotwo.setVisible(true);

        //odpalenie timera na panelboardzie
        tm =new Timer(30,panelboard);
        tm.start();

    }

    /**
     * Metoda obslugujaca zdarzenia zakmniecia okna gry, przwracajaca ustawienia domyslne
     * @param e
     */
    public void windowClosing(WindowEvent e) {
        try{
            tm.stop();//zatrzymanie timera
            PanelBoard.MakeDefaultOption(1);//przywrocenie domyslnych parametrow
            this.dispose();//zamkniecie okna
            Amountofpoints=0;
        }catch(Exception error){
            System.out.println(error+"Blad zamkniecia levelframe - klasa levelframe, metoda windowClosing");
        }
    }
   //metody wymagane przez interfejs, przydadza sie pozniej
    public void windowActivated(WindowEvent e) {
    }
    public void windowClosed(WindowEvent e) {
    }
    public void windowDeactivated(WindowEvent e) {
    }
    public void windowDeiconified(WindowEvent e) {
    }
    public void windowIconified(WindowEvent e) {
    }
    public void windowOpened(WindowEvent e) {
    }
    public void actionPerformed(ActionEvent e) {
    }
}
